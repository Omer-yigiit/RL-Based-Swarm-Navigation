#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>

#include <webots/robot.h>
#include <webots/motor.h>
#include <webots/gps.h>
#include <webots/compass.h>
#include <webots/emitter.h>
#include <webots/receiver.h>
#include <webots/distance_sensor.h>

// --- AYARLAR ---
#define TIME_STEP 64
#define MAX_SPEED 3.0
#define COMMUNICATION_CHANNEL 1

// HEDEF: 1.5 Metre Düz Git (Start: 0.0 -> End: 1.5)
#define TARGET_DISTANCE 1.5 

// Formasyon Mesafeleri (Liderin Arkasındaki Konumlar)
#define OFFSET_FRONT -0.15  // ps2 (Orta)
#define OFFSET_BACK  -0.25  // ps1 ve ps3 (Kanatlar)
#define OFFSET_SIDE   0.15  // Yanal açıklık

#define OBSTACLE_TH 80.0
#define FORMATION_TOLERANCE 0.08 // 8cm hata payı
#define STOP_DIST_TARGET 0.05

static WbDeviceTag left_motor, right_motor;
static WbDeviceTag gps, compass, emitter, receiver;
static WbDeviceTag distance_sensors[8];
static const char *ps_names[8] = {"ps0", "ps1", "ps2", "ps3", "ps4", "ps5", "ps6", "ps7"};
static double ps_values[8];

static double weights[8][2] = {
  {-1.5, -1.0}, {-1.5, -1.0}, {-0.5, 0.5}, {0.0, 0.0},
  {0.0, 0.0},   {0.5, -0.5},  {1.0, 1.5},  {1.0, 1.5}
};

typedef struct {
  double x, z, theta;
  double v_cmd;
  bool is_waiting;
} LeaderPacket;

typedef struct {
  int id;
  double error;
} FollowerPacket;

// --- Yardımcı Fonksiyonlar ---

static double clamp(double v, double lo, double hi) {
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

static double normalize_angle(double angle) {
  while (angle > M_PI) angle -= 2.0 * M_PI;
  while (angle < -M_PI) angle += 2.0 * M_PI;
  return angle;
}

static int get_robot_id() {
  const char *name = wb_robot_get_name();
  int len = strlen(name);
  if (len > 0 && name[len-1] >= '0' && name[len-1] <= '9') return name[len-1] - '0';
  return 0;
}

static double get_heading() {
  const double *north = wb_compass_get_values(compass);
  if (!north) return 0.0;
  return atan2(north[0], north[2]); 
}

// Formasyon Ofsetleri
static void get_formation_offsets(int id, double *f, double *s) {
  *f = 0.0; *s = 0.0;
  if (id == 2) { *f = OFFSET_FRONT; *s = 0.0; } 
  else if (id == 1) { *f = OFFSET_BACK; *s = OFFSET_SIDE; } 
  else if (id == 3) { *f = OFFSET_BACK; *s = -OFFSET_SIDE; } 
}

void init_devices() {
  for (int i = 0; i < 8; i++) {
    distance_sensors[i] = wb_robot_get_device(ps_names[i]);
    if (distance_sensors[i]) wb_distance_sensor_enable(distance_sensors[i], TIME_STEP);
  }
  left_motor = wb_robot_get_device("left wheel motor");
  right_motor = wb_robot_get_device("right wheel motor");
  if (left_motor) { wb_motor_set_position(left_motor, INFINITY); wb_motor_set_velocity(left_motor, 0.0); }
  if (right_motor) { wb_motor_set_position(right_motor, INFINITY); wb_motor_set_velocity(right_motor, 0.0); }

  gps = wb_robot_get_device("gps");
  if (!gps) gps = wb_robot_get_device("gps0"); 
  if (gps) wb_gps_enable(gps, TIME_STEP);

  compass = wb_robot_get_device("compass");
  if (!compass) compass = wb_robot_get_device("compass0"); 
  if (compass) wb_compass_enable(compass, TIME_STEP);

  emitter = wb_robot_get_device("emitter");
  if (!emitter) emitter = wb_robot_get_device("emitter0");
  if (emitter) wb_emitter_set_channel(emitter, COMMUNICATION_CHANNEL);

  receiver = wb_robot_get_device("receiver");
  if (!receiver) receiver = wb_robot_get_device("receiver0");
  if (receiver) { wb_receiver_enable(receiver, TIME_STEP); wb_receiver_set_channel(receiver, COMMUNICATION_CHANNEL); }
}

int main() {
  wb_robot_init();
  init_devices();
  
  int my_id = get_robot_id();
  double my_x = 0, my_z = 0, my_theta = 0;
  
  LeaderPacket leader_pkt = {0};
  bool leader_seen = false;
  
  // Düzeltilen Değişken İsimleri
  double max_follower_error = 0.0; 

  // Lider Başlangıç Konumu
  double start_x = 0.0;
  bool start_recorded = false;

  // Lider Hızı
  double leader_speed = MAX_SPEED * 0.6;

  while (wb_robot_step(TIME_STEP) != -1) {
    if (wb_robot_get_time() < 0.5) continue;

    const double *p = wb_gps_get_values(gps);
    if (p) { 
        my_x = p[0]; my_z = p[2]; 
        if(!start_recorded && my_id==0) { start_x = my_x; start_recorded=true; }
    } 
    if (compass) my_theta = get_heading(); // DÜZELTİLDİ: my_th -> my_theta

    // Engel Algılama
    double b_left = 0, b_right = 0;
    bool obstacle = false;
    for (int i=0; i<8; i++) {
        ps_values[i] = (distance_sensors[i]) ? wb_distance_sensor_get_value(distance_sensors[i]) : 0;
        if (ps_values[i] > OBSTACLE_TH) {
            obstacle = true;
            b_left += ps_values[i] * weights[i][0];
            b_right += ps_values[i] * weights[i][1];
        }
    }
    b_left *= 0.005; b_right *= 0.005;

    double left_cmd = 0.0, right_cmd = 0.0;

    // ================== LİDER (PS0) ==================
    if (my_id == 0) {
      // 1. Takipçileri Dinle
      max_follower_error = 0.0; // DÜZELTİLDİ: max_err -> max_follower_error
      while (wb_receiver_get_queue_length(receiver) > 0) {
        if (wb_receiver_get_data_size(receiver) == sizeof(FollowerPacket)) {
           FollowerPacket *fp = (FollowerPacket*)wb_receiver_get_data(receiver);
           if (fp->error > max_follower_error) max_follower_error = fp->error;
        }
        wb_receiver_next_packet(receiver);
      }

      double dist_traveled = fabs(my_x - start_x);
      double base_v = 0.0;

      // 2. Bekleme Kararı (DÜZELTİLDİ: FORMATION_TOLERANCE kullanıldı)
      bool wait = (max_follower_error > FORMATION_TOLERANCE);
      if (wb_robot_get_time() < 2.0) wait = true; 

      if (dist_traveled >= TARGET_DISTANCE) {
         // Hedefe Vardı
         base_v = 0.0; 
      } 
      else if (wait) {
         // Formasyon bozuk, BEKLE
         base_v = 0.0;
      }
      else {
         // GAZLA (Sadece Düz)
         base_v = leader_speed;
      }

      // --- DİREKSİYON YOK ---
      left_cmd = base_v;
      right_cmd = base_v;

      if (obstacle) {
          left_cmd += b_left;
          right_cmd += b_right;
      }

      if (emitter) {
        LeaderPacket pkt;
        pkt.x = my_x; pkt.z = my_z; pkt.theta = my_theta;
        pkt.v_cmd = base_v; 
        pkt.is_waiting = wait; // DÜZELTİLDİ: waiting -> is_waiting
        wb_emitter_send(emitter, &pkt, sizeof(pkt));
      }
    }
    
    // ================== TAKİPÇİLER ==================
    else {
      while (wb_receiver_get_queue_length(receiver) > 0) {
        if (wb_receiver_get_data_size(receiver) == sizeof(LeaderPacket)) {
           memcpy(&leader_pkt, wb_receiver_get_data(receiver), sizeof(LeaderPacket));
           leader_seen = true;
        }
        wb_receiver_next_packet(receiver);
      }

      if (leader_seen) {
        double off_f, off_s;
        // DÜZELTİLDİ: Fonksiyon ismi get_formation_offsets
        get_formation_offsets(my_id, &off_f, &off_s);

        double c = cos(leader_pkt.theta);
        double s = sin(leader_pkt.theta);

        // Hedef Hesapla
        double target_x = leader_pkt.x + (off_f * c - off_s * s);
        double target_z = leader_pkt.z + (off_f * s + off_s * c);

        double dx = target_x - my_x;
        double dz = target_z - my_z;
        double dist_err = sqrt(dx*dx + dz*dz);
        double target_h = atan2(dz, dx);
        double head_err = normalize_angle(target_h - my_theta);

        // Raporla
        if(emitter) {
            FollowerPacket fp; 
            fp.id = my_id; 
            fp.error = dist_err;
            wb_emitter_send(emitter, &fp, sizeof(fp));
        }

        // Hareket
        double base_v = 0.0;
        double turn_v = 0.0;

        if (dist_err > 0.05) { 
            if (fabs(head_err) > 0.6) {
                base_v = 0.0;
                turn_v = (head_err > 0) ? 2.5 : -2.5; 
            } else {
                base_v = dist_err * 6.0; 
                turn_v = head_err * 4.0;
            }
        } 
        else {
            base_v = leader_pkt.v_cmd; 
            turn_v = head_err * 2.0;
        }

        if (obstacle) {
            left_cmd = base_v + b_left;
            right_cmd = base_v + b_right;
        } else {
            left_cmd = base_v - turn_v;
            right_cmd = base_v + turn_v;
        }
      }
    }

    left_cmd  = clamp(left_cmd, -MAX_SPEED, MAX_SPEED);
    right_cmd = clamp(right_cmd, -MAX_SPEED, MAX_SPEED);
    
    wb_motor_set_velocity(left_motor, left_cmd);
    wb_motor_set_velocity(right_motor, right_cmd);
  }

  wb_robot_cleanup();
  return 0;
}