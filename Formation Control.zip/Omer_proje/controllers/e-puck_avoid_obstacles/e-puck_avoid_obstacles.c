#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include <webots/device.h>
#include <webots/distance_sensor.h>
#include <webots/led.h>
#include <webots/motor.h>
#include <webots/robot.h>

#define DISTANCE_SENSORS_NUMBER 8
static WbDeviceTag distance_sensors[DISTANCE_SENSORS_NUMBER];
static double distance_sensors_values[DISTANCE_SENSORS_NUMBER];
static const char *distance_sensors_names[DISTANCE_SENSORS_NUMBER] = {
  "ps0","ps1","ps2","ps3","ps4","ps5","ps6","ps7"
};

#define GROUND_SENSORS_NUMBER 3
static WbDeviceTag ground_sensors[GROUND_SENSORS_NUMBER];
static double ground_sensors_values[GROUND_SENSORS_NUMBER] = {0.0,0.0,0.0};
static const char *ground_sensors_names[GROUND_SENSORS_NUMBER] = {"gs0","gs1","gs2"};

#define LEDS_NUMBER 10
static WbDeviceTag leds[LEDS_NUMBER];
static bool leds_values[LEDS_NUMBER];
static const char *leds_names[LEDS_NUMBER] = {
  "led0","led1","led2","led3","led4","led5","led6","led7","led8","led9"
};

static WbDeviceTag left_motor, right_motor;

#define LEFT 0
#define RIGHT 1
#define MAX_SPEED 6.28
static double speeds[2];

/* Braitenberg weights */
static double weights[DISTANCE_SENSORS_NUMBER][2] = {
  {-1.0, -0.5}, {-1.3, -0.5}, {-0.5, 0.5}, {0.0,0.0},
  {0.0,0.0}, {0.5,-0.5}, {0.5,-0.75}, {0.5,-1.0}
};
/* Offset biraz düşürüldü */
static double offsets[2] = {0.3*MAX_SPEED, 0.3*MAX_SPEED};

static int get_time_step() {
  static int time_step=-1;
  if(time_step==-1)
    time_step = (int)wb_robot_get_basic_time_step();
  return time_step;
}

static void step_func() {
  if(wb_robot_step(get_time_step())==-1) {
    wb_robot_cleanup();
    exit(EXIT_SUCCESS);
  }
}

static void init_devices() {
  int i;
  for(i=0;i<DISTANCE_SENSORS_NUMBER;i++){
    distance_sensors[i]=wb_robot_get_device(distance_sensors_names[i]);
    wb_distance_sensor_enable(distance_sensors[i],get_time_step());
  }
  for(i=0;i<LEDS_NUMBER;i++)
    leds[i]=wb_robot_get_device(leds_names[i]);

  for(i=0;i<GROUND_SENSORS_NUMBER;i++)
    ground_sensors[i]=(WbDeviceTag)0;
  int ndevices = wb_robot_get_number_of_devices();
  for(i=0;i<ndevices;i++){
    WbDeviceTag dtag = wb_robot_get_device_by_index(i);
    const char *dname = wb_device_get_name(dtag);
    WbNodeType dtype = wb_device_get_node_type(dtag);
    if(dtype==WB_NODE_DISTANCE_SENSOR && strlen(dname)==3 && dname[0]=='g' && dname[1]=='s'){
      int id = dname[2]-'0';
      if(id>=0 && id<GROUND_SENSORS_NUMBER){
        ground_sensors[id]=wb_robot_get_device(ground_sensors_names[id]);
        wb_distance_sensor_enable(ground_sensors[id],get_time_step());
      }
    }
  }

  left_motor = wb_robot_get_device("left wheel motor");
  right_motor = wb_robot_get_device("right wheel motor");
  wb_motor_set_position(left_motor,INFINITY);
  wb_motor_set_position(right_motor,INFINITY);
  wb_motor_set_velocity(left_motor,0.0);
  wb_motor_set_velocity(right_motor,0.0);

  step_func();
}

static void reset_actuator_values() {
  for(int i=0;i<2;i++) speeds[i]=0.0;
  for(int i=0;i<LEDS_NUMBER;i++) leds_values[i]=false;
}

static void get_sensor_input() {
  for(int i=0;i<DISTANCE_SENSORS_NUMBER;i++)
    distance_sensors_values[i]=wb_distance_sensor_get_value(distance_sensors[i]); // ham değer
  for(int i=0;i<GROUND_SENSORS_NUMBER;i++)
    if(ground_sensors[i])
      ground_sensors_values[i]=wb_distance_sensor_get_value(ground_sensors[i]);
}

static bool cliff_detected() {
  for(int i=0;i<GROUND_SENSORS_NUMBER;i++){
    if(!ground_sensors[i]) return false;
    if(ground_sensors_values[i]<500.0) return true;
  }
  return false;
}

static void set_actuators() {
  for(int i=0;i<LEDS_NUMBER;i++)
    wb_led_set(leds[i],leds_values[i]);
  wb_motor_set_velocity(left_motor,speeds[LEFT]);
  wb_motor_set_velocity(right_motor,speeds[RIGHT]);
}

static void blink_leds() {
  static int counter=0;
  counter++;
  leds_values[(counter/10)%LEDS_NUMBER]=true;
}

static void run_braitenberg() {
  double threshold = 80.0; // engeli daha uzaktan algılamak için eşik
  double gain = 2.0;       // engeli görünce etkiyi artırma

  for(int i=0;i<2;i++){
    speeds[i]=0.0;
    for(int j=0;j<DISTANCE_SENSORS_NUMBER;j++){
      if(distance_sensors_values[j] > threshold) {
        speeds[i]+=distance_sensors_values[j]*weights[j][i]*gain;
      }
    }
    speeds[i]=offsets[i]+speeds[i]*(MAX_SPEED/4000.0); // sensör 0–4096 ölçeği için normalize
    if(speeds[i]>MAX_SPEED) speeds[i]=MAX_SPEED;
    else if(speeds[i]<-MAX_SPEED) speeds[i]=-MAX_SPEED;
  }
}

int main(int argc,char **argv){
  wb_robot_init();
  printf("Default controller of the e-puck robot started...\n");
  init_devices();

  while(true){
    reset_actuator_values();
    get_sensor_input();
    blink_leds();

    if(cliff_detected()){
      speeds[LEFT]=-MAX_SPEED;
      speeds[RIGHT]=-MAX_SPEED;
    } else {
      run_braitenberg();
    }

    set_actuators();
    step_func();
  }

  return EXIT_SUCCESS;
}
