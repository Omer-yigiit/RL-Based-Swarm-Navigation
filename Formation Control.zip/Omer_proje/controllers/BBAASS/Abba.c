#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>

#include <webots/device.h>
#include <webots/distance_sensor.h>
#include <webots/motor.h>
#include <webots/robot.h>
#include <webots/gps.h>
#include <webots/compass.h> // Compass kütüphanesi eklendi
#include <webots/emitter.h>
#include <webots/receiver.h>

#define MAX_SPEED 2
#define TIME_STEP 64
#define COMMUNICATION_CHANNEL 1
#define DISTANCE_SENSORS_NUMBER 8

// ------------ TUNING ------------
#define OBSTACLE_TH 80.0
#define PASS_LANE 0.24
#define PASS_MIN_TIME 2.8
#define CLEAR_STEPS 8
#define PS3_WAIT_TIME 2.0
#define K_DIST 14.0
#define K_ANGLE 3.8
#define DEAD_ANGLE 0.10
#define ROT_INPLACE_TH 0.85
#define STOP_DIST 0.02
#define HEADING_SPEED_MIN 0.02
#define HEADING_ALPHA 0.20
#define TRI_SIDE    0.30
#define TRI_HEIGHT (TRI_SIDE * sqrt(3.0) / 2.0)
// --------------------------------

static WbDeviceTag distance_sensors[DISTANCE_SENSORS_NUMBER];
static double ps_values[DISTANCE_SENSORS_NUMBER];
static const char *ps_names[DISTANCE_SENSORS_NUMBER] = {
  "ps0", "ps1", "ps2", "ps3", "ps4", "ps5", "ps6", "ps7"
};

static WbDeviceTag left_motor, right_motor;
static WbDeviceTag gps, compass, emitter, receiver; // Compass eklendi

static double weights[8][2] = {
  {-1.5, -1.0}, {-1.5, -1.0}, {-0.5, 0.5}, {0.0, 0.0},
  {0.0, 0.0},   {0.5, -0.5},  {1.0, 1.5},  {1.0, 1.5}
};

typedef enum { MODE_CRUISE = 0, MODE_PASS = 1 } Mode;

typedef struct {
  double x, z;
  double theta;
  double v;
  int mode;
  int phase;
  double t;
} LeaderPacket;

static int my_id = -1;
static double my_pos[3]; // x, z, theta

// Heading state
static bool have_last_gps = false;
static double last_x = 0.0, last_z = 0.0;
static double theta_est = 0.0;

static double clamp(double v, double lo, double hi) {
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

static double wrap_pi(double a) {
  while (a > M_PI) a -= 2.0 * M_PI;
  while (a < -M_PI) a += 2.0 * M_PI;
  return a;
}

static double smooth_angle(double prev, double cur, double alpha) {
  double d = wrap_pi(cur - prev);
  return wrap_pi(prev + alpha * d);
}

static WbDeviceTag get_device_any(const char *a, const char *b, const char *c) {
  WbDeviceTag t = 0;
  if (a) { t = wb_robot_get_device(a); if (t) return t; }
  if (b) { t = wb_robot_get_device(b); if (t) return t; }
  if (c) { t = wb_robot_get_device(c); if (t) return t; }
  return 0;
}

int get_robot_id() {
  const char* name = wb_robot_get_name();
  int len = (int)strlen(name);
  if (len > 0 && name[len-1] >= '0' && name[len-1] <= '9')
    return name[len-1] - '0';
  return 0;
}

// GPS'ten heading hesaplama (Compass yoksa)
static double get_heading_from_gps(double x, double z, double *out_speed) {
  const double dt = TIME_STEP / 1000.0;
  if (!have_last_gps) { *out_speed = 0.0; return NAN; }
  double vx = (x - last_x) / dt;
  double vz = (z - last_z) / dt;
  double sp = sqrt(vx*vx + vz*vz);
  *out_speed = sp;
  if (sp < HEADING_SPEED_MIN) return NAN;
  return atan2(vz, vx);
}

// Compass'tan heading alma (Daha kararlı)
double get_compass_heading() {
    const double *north = wb_compass_get_values(compass);
    if (!north) return 0.0;
    // Webots X-Z düzlemi için (X=Kuzey ise)
    double angle = atan2(north[0], north[2]);
    return angle;
}

void init_devices() {
  for (int i = 0; i < DISTANCE_SENSORS_NUMBER; i++) {
    distance_sensors[i] = wb_robot_get_device(ps_names[i]);
    if (distance_sensors[i])
      wb_distance_sensor_enable(distance_sensors[i], TIME_STEP);
  }

  left_motor  = get_device_any("left wheel motor",  "left_motor",  "left wheel");
  right_motor = get_device_any("right wheel motor", "right_motor", "right wheel");
  if (left_motor)  { wb_motor_set_position(left_motor, INFINITY);  wb_motor_set_velocity(left_motor, 0.0); }
  if (right_motor) { wb_motor_set_position(right_motor, INFINITY); wb_motor_set_velocity(right_motor, 0.0); }

  gps = get_device_any("gps", "gps0", NULL);
  if (gps) wb_gps_enable(gps, TIME_STEP);

  compass = get_device_any("compass", "compass0", NULL);
  if (compass) wb_compass_enable(compass, TIME_STEP);

  emitter  = get_device_any("emitter",  "emitter0",  "emitter1");
  receiver = get_device_any("receiver", "receiver0", "receiver1");
  
  if (emitter) {
    wb_emitter_set_channel(emitter, COMMUNICATION_CHANNEL);
    wb_emitter_set_range(emitter, 100.0);
  }
  if (receiver) {
    wb_receiver_enable(receiver, TIME_STEP);
    wb_receiver_set_channel(receiver, COMMUNICATION_CHANNEL);
  }
}

int main(int argc, char **argv) {
  wb_robot_init();
  init_devices();

  printf("ROBOT BASLADI: %s (ID: %d)\n", wb_robot_get_name(), get_robot_id());
  my_id = get_robot_id();

  double left_speed = 0.0, right_speed = 0.0;

  LeaderPacket leader_data;
  memset(&leader_data, 0, sizeof(LeaderPacket));
  bool leader_data_received = false;

  Mode leader_mode = MODE_CRUISE;
  double pass_start_time = -1.0;
  int clear_counter = 0;

  while (wb_robot_step(TIME_STEP) != -1) {

    // GPS/Sensör Isınma Süresi
    if (wb_robot_get_time() < 1.0) {
      if (left_motor) wb_motor_set_velocity(left_motor, 0.0);
      if (right_motor) wb_motor_set_velocity(right_motor, 0.0);
      continue;
    }

    // Sensörleri Oku
    for (int i = 0; i < 8; i++)
      ps_values[i] = (distance_sensors[i]) ? wb_distance_sensor_get_value(distance_sensors[i]) : 0.0;

    // Konum Güncelle
    if (gps) {
      const double *vals = wb_gps_get_values(gps);
      if (vals) { my_pos[0] = vals[0]; my_pos[1] = vals[2]; }
    }

    // Heading Güncelle (Compass varsa onu kullan, yoksa GPS)
    if (compass) {
        my_pos[2] = get_compass_heading();
    } else {
        double sp = 0.0;
        double theta_vel = get_heading_from_gps(my_pos[0], my_pos[1], &sp);
        if (!isnan(theta_vel)) theta_est = smooth_angle(theta_est, theta_vel, HEADING_ALPHA);
        my_pos[2] = theta_est;
    }

    // GPS Geçmişini Güncelle
    if (!have_last_gps) { have_last_gps = true; last_x = my_pos[0]; last_z = my_pos[1]; }
    else { last_x = my_pos[0]; last_z = my_pos[1]; }

    // Engel Algılama
    double b_left = 0.0, b_right = 0.0;
    bool obstacle = false;
    for (int i = 0; i < 8; i++) {
      if (ps_values[i] > OBSTACLE_TH) {
        obstacle = true;
        b_left  += ps_values[i] * weights[i][0];
        b_right += ps_values[i] * weights[i][1];
      }
    }
    b_left  *= 0.003;
    b_right *= 0.003;

    bool front_blocked = (ps_values[0] > OBSTACLE_TH || ps_values[7] > OBSTACLE_TH ||
                          ps_values[6] > OBSTACLE_TH || ps_values[1] > OBSTACLE_TH);

    // ---------------- LİDER (ps0) ----------------
    if (my_id == 0) {
      double now = wb_robot_get_time();

      if (leader_mode == MODE_CRUISE) {
        if (front_blocked) {
          leader_mode = MODE_PASS;
          pass_start_time = now;
          clear_counter = 0;
          printf("[LIDER] Engel Tespit Edildi -> PASS Moduna Geciliyor\n");
        }
      } else { // MODE_PASS
        if (now - pass_start_time > PASS_MIN_TIME) {
          if (!front_blocked) {
            clear_counter++;
            if (clear_counter >= CLEAR_STEPS) {
              leader_mode = MODE_CRUISE;
              pass_start_time = -1.0;
              clear_counter = 0;
              printf("[LIDER] Engel Asildi -> CRUISE Moduna Donuluyor\n");
            }
          } else clear_counter = 0;
        }
      }

      double base = (leader_mode == MODE_PASS) ? (MAX_SPEED * 0.35) : (MAX_SPEED * 0.50);
      left_speed  = base + b_left;
      right_speed = base + b_right;

      if (leader_mode == MODE_PASS) {
        left_speed  = clamp(left_speed,  -MAX_SPEED*0.60, MAX_SPEED*0.60);
        right_speed = clamp(right_speed, -MAX_SPEED*0.60, MAX_SPEED*0.60);
      }

      // Veri Gönderimi (Broadcast)
      if (emitter) {
        LeaderPacket pkt;
        pkt.x = my_pos[0];
        pkt.z = my_pos[1];
        pkt.theta = my_pos[2];
        pkt.v = 0.5 * (left_speed + right_speed);
        pkt.mode = (int)leader_mode;
        pkt.phase = 0;
        if (leader_mode == MODE_PASS && pass_start_time > 0.0) {
          if ((now - pass_start_time) > PS3_WAIT_TIME) pkt.phase = 1;
        }
        pkt.t = now;

        wb_emitter_send(emitter, &pkt, (int)sizeof(LeaderPacket));
      }
    }

    // ---------------- TAKİPÇİLER (ps1-ps3) ----------------
    if (my_id != 0) {
      if (receiver) {
        while (wb_receiver_get_queue_length(receiver) > 0) {
          // Paketi al
          const void *buffer = wb_receiver_get_data(receiver);
          // Boyut kontrolü yapmadan önce veriyi kopyala (daha güvenli)
          if (buffer) {
              memcpy(&leader_data, buffer, sizeof(LeaderPacket));
              leader_data_received = true;
          }
          wb_receiver_next_packet(receiver);
        }
      }

      if (leader_data_received) {
        double dx = 0.0, dy = 0.0;

        if (leader_data.mode == MODE_CRUISE) {
          // Eşkenar Üçgen Formasyonu
          if (my_id == 1) { dx = -TRI_HEIGHT;       dy = +TRI_SIDE / 2.0; }
          if (my_id == 2) { dx = -TRI_HEIGHT;       dy = -TRI_SIDE / 2.0; }
          if (my_id == 3) { dx = -2.0 * TRI_HEIGHT; dy = 0.0; }
        } else {
          // Geçiş Formasyonu (Düz Sıra)
          if (my_id == 1) { dx = -0.12; dy = +PASS_LANE; }
          if (my_id == 2) { dx = -0.12; dy = -PASS_LANE; }
          if (my_id == 3) {
            if (leader_data.phase == 0) { dx = -0.75; dy = 0.0; } // Bekle
            else                        { dx = -0.32; dy = 0.0; } // Gir
          }
        }

        // Koordinat Dönüşümü
        double c = cos(leader_data.theta);
        double s = sin(leader_data.theta);

        double target_x = leader_data.x + (dx * c - dy * s);
        double target_z = leader_data.z + (dx * s + dy * c);

        double ex = target_x - my_pos[0];
        double ez = target_z - my_pos[1];

        double dist = sqrt(ex*ex + ez*ez);
        double target_angle = atan2(ez, ex);
        double angle_diff = wrap_pi(target_angle - my_pos[2]);

        // Hız Kontrolü
        double base_v = leader_data.v + K_DIST * dist;
        base_v = clamp(base_v, 0.0, MAX_SPEED);
        if (dist < STOP_DIST) base_v = leader_data.v;

        double rot_v = 0.0;
        if (fabs(angle_diff) < DEAD_ANGLE) {
          rot_v = 0.0;
        } else if (fabs(angle_diff) > ROT_INPLACE_TH) {
          base_v *= 0.35;
          rot_v = (angle_diff > 0) ? 1.6 : -1.6;
        } else {
          rot_v = angle_diff * K_ANGLE;
        }

        if (leader_data.mode == MODE_PASS && my_id == 3 && leader_data.phase == 0) {
          base_v *= 0.45;
          rot_v  *= 0.60;
        }

        left_speed  = base_v - rot_v;
        right_speed = base_v + rot_v;

        // Engelden Kaçış
        if (obstacle) {
          double mix = (leader_data.mode == MODE_PASS) ? 0.12 : 0.20;
          left_speed  = b_left  + base_v * mix;
          right_speed = b_right + base_v * mix;
        }
      } else {
          // Veri gelmediyse dur
          left_speed = 0;
          right_speed = 0;
      }
    }

    // Hız Limitleme ve Uygulama
    left_speed  = clamp(left_speed,  -MAX_SPEED, MAX_SPEED);
    right_speed = clamp(right_speed, -MAX_SPEED, MAX_SPEED);

    if (left_motor)  wb_motor_set_velocity(left_motor, left_speed);
    if (right_motor) wb_motor_set_velocity(right_motor, right_speed);
  }

  wb_robot_cleanup();
  return 0;
}
